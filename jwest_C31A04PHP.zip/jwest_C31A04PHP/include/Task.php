<?php

class Task implements JsonSerializable
{
    private $id;
    private $title;
    private $desc;
    private $dateCreated;
    private $dateModified;
    private $status;

    static private $nextId = 0;
    public const STATUSES = [
        "all",
        "todo",
        "indev",
        "intest",
        "complete"
        ];

    public function __construct($data)
    {
        $this->fill($data);
        if (!isset($this->id))
            $this->id = self::$nextId;
        self::$nextId++;
    }

    public function fill($info)
    {
        foreach ($info as $key => $val)
            $this->{$key} = $val;
    }

    public function getDateCreated()
    {
        return $this->dateCreated;
    }
    public function getDateModified()
    {
        return $this->dateModified;
    }
    public function getId()
    {
        return $this->id;
    }
    public function getTitle()
    {
        return $this->title;
    }
    public function getDesc()
    {
        return $this->desc;
    }
    public function getStatus()
    {
        return $this->status;
    }

    public function setDateCreated($c)
    {
        $this->dateCreated = $c;
    }
    public function setDateModified($m)
    {
        $this->dateModified = $m;
    }
    public function setId($id)
    {
        $this->id = $id;
    }
    public function setTitle($t)
    {
        $this->title = $t;
    }
    public function setDesc($d)
    {
        $this->desc = $d;
    }
    public function setStatus($s)
    {
        $this->status = $s;
    }

    static public function getNextId()
    {
        return self::$nextId;
    }

    static public function compareDate(Task $a, Task $b)
    {
        if ($a->getDateModified() == $b->getDateModified())
            return 0;
        else
            return ($a->getDateModified() < $b->getDateModified())? 1: -1;
    }
    static public function numToStatus($s)
    {
        $str = "";
        switch ($s)
        {
            case 0:
                $str = "All";
                break;
            case 1:
                $str = "To Do";
                break;
            case 2:
                $str = "In Development";
                break;
            case 3:
                $str = "Testing";
                break;
            case 4:
                $str = "Complete";
                break;
            default:
                $str = "Unknown";
        }
        return $str;
    }

    public function jsonSerialize()
    {
        return [
            "id" => $this->id,
            "title" => $this->title,
            "desc" => $this->desc,
            "dateCreated" => $this->dateCreated,
            "dateModified" => $this->dateModified,
            "status" => $this->status
        ];
    }

}