<?php
    require_once("./include/functions.inc");
    require_once("./include/Task.php");

    $notificationMsg = "";
    $tasks = array();

    if (!is_dir("./List"))
        mkdir("./List");
    if (file_exists("./List/tasks.json"))
    {
        $tasksJSON = json_decode(file_get_contents("./List/tasks.json"), true);
        foreach ($tasksJSON as $task)
            array_push($tasks, new Task($task));
    }

    $goToEdit = (isset($_POST["edit"]) and !isset($_POST["cancel"]));

    if (isset($_POST["commitChange"]))
    {
        $editValid = true;
        $title = $_POST["title"];
        $desc = $_POST["desc"];

        if (empty($title))
        {
            $editValid = false;
            $titleMsg = "Please give the task a title.";
        }
        if (empty($desc))
        {
            $editValid = false;
            $descMsg = "Please describe the task.";
        }

        $goToEdit = !$editValid;
        if ($editValid)
        {
            $currTask = null;
            $i = 0;
            while ($i < sizeof($tasks) and $currTask == null)
            {
                if ($_POST["edit"] == $tasks[$i]->getId())
                {
                    $tasks[$i]->fill($_POST);
                    $tasks[$i]->setDateModified(date("Ymd"));
                    $currTask = &$tasks[$i];
                }
                $i++;
            }

            $notificationMsg = "Successfully altered " . $currTask->getTitle() . ".";

            file_put_contents("./List/tasks.json", json_encode($tasks, JSON_PRETTY_PRINT));
        }
    }

    $selectedTab = "todo";
    if (isset($_POST["selectedTab"]))
        $selectedTab = $_POST["selectedTab"];
    else if (isset($_POST["status"]))
        $selectedTab = Task::STATUSES[(int) $_POST["status"]];

    if ($goToEdit)
    {
        var_dump($_POST);
        $titleMsg = "";
        $descMsg = "";

        if (isset($_POST["commitChange"]))
        {
            $title = $_POST["title"];
            $desc = $_POST["desc"];
        }

        $currTask = null;
        $i = 0;
        while ($i < sizeof($tasks) and $currTask == null)
        {
            if ($tasks[$i] != null)
            {
                if ($_POST["edit"] == $tasks[$i]->getId())
                    $currTask = $tasks[$i];
            }
            $i++;
        }
        ?>
        <!DOCTYPE html> <!-- EDIT FORM /-->
        <html lang="en">
        <head>
            <title>Edit <?php echo $currTask->getTitle(); ?></title>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width">
            <link rel="stylesheet" href="../public/styles/style.css"/>
        </head>
        <body>
        <header>
            <h2>Edit Task</h2>
        </header>
        <main>
            <form method="post" action="./manageTasks.php">
                <p>
                    <label for="title">Title:</label>
                    <input type="text" name="title" id="title" class="<?php echo (empty($titleMsg))?"":"invalid error"; ?>" value="<?php echo $currTask->getTitle(); ?>"/>
                    <span class="errorMsg"><?php echo $titleMsg; ?></span>
                </p>
                <p>
                    <label for="desc">Description:</label>
                    <textarea name="desc" id="desc" class="<?php echo (empty($descMsg))?"":"invalid error"; ?>"><?php echo $currTask->getDesc();?></textarea>
                    <span class="errorMsg"><?php echo $descMsg; ?></span>
                </p>
                <p>
                    <label for="status">Status:</label>
                    <select id="status" <?php echo ($currTask->getStatus() == 4)?"disabled":""; ?> name="status">
                        <?php
                        if ($currTask->getStatus() == 1)
                        {
                            ?>
                            <option selected value="1">To Do</option>
                            <option value="2">In Development</option>
                            <?php
                        }
                        elseif ($currTask->getStatus() == 2)
                        {
                            ?>
                            <option selected value="2">In Development</option>
                            <option value="3">Testing</option>
                            <?php
                        }
                        elseif ($currTask->getStatus() == 3)
                        {
                            ?>
                            <option value="2">In Development</option>
                            <option selected value="3">Testing</option>
                            <option value="4">Complete</option>
                            <?php
                        }
                        else
                        {
                            ?>
                            <option selected value="4">Complete</option>
                            <?php
                        }
                        ?>
                    </select>
                    <?php
                        if ($currTask->getStatus() == 4)
                        {
                            ?>
                            <input type="hidden" value="4" name="status"/>
                            <?php
                        }
                    ?>
                </p>
                <p>
                    <label>&nbsp;</label>
                    <input type="submit" name="commitChange" id="update" value="Update"/>
                    <input type="submit" name="cancel" id="cancel" value="Cancel" class="secondary"/>
                </p>
                <input type="hidden" name="edit" value="<?php echo $currTask->getId() ?>"/>
                <input type="hidden" name="dateCreated" value="<?php echo $currTask->getDateCreated(); ?>"/>
                <input type="hidden" name="dateModified" value="<?php echo $currTask->getDateModified(); ?>"/>
            </form>
        </main>
        </body>
        </html>
        <?php
    }
else
{
    $title = "";
    $desc = "";

    $titleMsg = "";
    $descMsg = "";

    if (isset($_POST["newTask"]))
    {
        $title = $_POST["title"];
        $desc = $_POST["desc"];
        $valid = true;
        if (empty($title))
        {
            $valid = false;
            $titleMsg = "Please give the task a title.";
        }
        if (empty($desc))
        {
            $valid = false;
            $descMsg = "Please describe the task.";
        }

        if ($valid)
        {
            $newTask = new Task($_POST);
            $newTask->setTitle($title);
            $newTask->setDesc($desc);
            $newTask->setDateCreated(date("Ymd"));
            $newTask->setDateModified(date("Ymd"));
            $newTask->setStatus(1);

            array_push($tasks, $newTask);

            file_put_contents("./List/tasks.json", json_encode($tasks));

            $notificationMsg = "The task \"$title\" was successfully created!";

            //Blank fields to avoid sticky form after valid submission
            $title = "";
            $desc = "";
        }
    }
    usort($tasks, "Task::compareDate");
?>
<!DOCTYPE html> <!-- TABLES /-->
<html lang="en">
<head>
    <title>Tasks</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="../public/styles/style.css"/>
</head>
<body>
<header>
    <h2>Manage Tasks</h2>
</header>
<main>
    <div class="tabs">
        <div class="tab">
            <input type="radio" id="all" name="tabGrp" <?php echo ($selectedTab=="all")?"checked":""; ?>/>
            <label for="all">All</label>
            <div class="tabContent">
                <div class="tabContainer">
                    <form action="./manageTasks.php" method="post" class="ignoreFormatting">
                        <table class="expandLast hover">
                            <tr>
                                <th>Title</th>
                                <th>Created</th>
                                <th>Modified</th>
                                <th>Status</th>
                                <th>Description</th>
                            </tr>
                            <?php
                                $taskCount = 0;
                                foreach ($tasks as $task)
                                {
                                    $taskCount++;
                                    ?>
                                    <tr class="submitable">
                                        <td>
                                            <label for="a_task<?php echo $task->getId(); ?>"><?php echo $task->getTitle(); ?></label>
                                            <input type="submit" class="hide" name="edit" id="a_task<?php echo $task->getId(); ?>" value="<?php echo $task->getId(); ?>"/>
                                        </td>
                                        <td><label for="a_task<?php echo $task->getId(); ?>"><?php echo date("Y/m/d", strtotime($task->getDateCreated())); ?></label></td>
                                        <td><label for="a_task<?php echo $task->getId(); ?>"><?php echo date("Y/m/d", strtotime($task->getDateModified())); ?></label></td>
                                        <td><label for="a_task<?php echo $task->getId(); ?>"><?php echo Task::numToStatus($task->getStatus()); ?></label></td>
                                        <td><label for="a_task<?php echo $task->getId(); ?>"><?php echo $task->getDesc(); ?></label></td>
                                    </tr>
                                    <?php
                                }
                                if ($taskCount == 0)
                                {
                                    ?>
                                    <tr>
                                        <td colspan="4">There are currently no tasks.</td>
                                    </tr>
                                    <?php
                                }
                            ?>
                        </table>
                        <input type="hidden" name="selectedTab" value="all"/>
                    </form>
                </div>
            </div>
        </div>
        <div class="tab">
            <input type="radio" id="todo" name="tabGrp" value="todo" <?php echo ($selectedTab=="todo")?"checked":""; ?>/>
            <label for="todo">To Do</label>
            <div class="tabContent">
                <div class="tabContainer">
                    <form action="./manageTasks.php" method="post" class="ignoreFormatting">
                        <table class="expandLast hover">
                            <tr>
                                <th>Title</th>
                                <th>Created</th>
                                <th>Modified</th>
                                <th>Description</th>
                            </tr>
                            <?php
                            $todoCount = 0;
                            foreach ($tasks as $task)
                            {
                                if ($task->getStatus() == 1)
                                {
                                    $todoCount++;
                                    ?>
                                    <tr class="submitable">
                                        <td>
                                            <label for="t_task<?php echo $task->getId(); ?>"><?php echo $task->getTitle(); ?></label>
                                            <input type="submit" class="hide" name="edit" id="t_task<?php echo $task->getId(); ?>" value="<?php echo $task->getId(); ?>"/>
                                        </td>
                                        <td><label for="t_task<?php echo $task->getId(); ?>"><?php echo date("Y/m/d", strtotime($task->getDateCreated())); ?></label></td>
                                        <td><label for="t_task<?php echo $task->getId(); ?>"><?php echo date("Y/m/d", strtotime($task->getDateModified())); ?></label></td>
                                        <td><label for="t_task<?php echo $task->getId(); ?>"><?php echo $task->getDesc(); ?></label></td>
                                    </tr>
                                    <?php
                                }
                            }
                            if ($todoCount == 0)
                            {
                                ?>
                                <tr>
                                    <td colspan="4">There are currently no tasks to do.</td>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                        <input type="hidden" name="selectedTab" value="todo"/>
                    </form>
                </div>
            </div>
        </div>
        <div class="tab">
            <input type="radio" id="indev" name="tabGrp" value="indev" <?php echo ($selectedTab=="indev")?"checked":""; ?>/>
            <label for="indev">In Development</label>
            <div class="tabContent">
                <div class="tabContainer">
                    <form action="./manageTasks.php" method="post" class="ignoreFormatting">
                        <table class="expandLast hover">
                            <tr>
                                <th>Title</th>
                                <th>Created</th>
                                <th>Modified</th>
                                <th>Description</th>
                            </tr>
                            <?php
                            $devCount = 0;
                            foreach ($tasks as $task)
                            {
                                if ($task->getStatus() == 2)
                                {
                                    $devCount++;
                                    ?>
                                    <tr class="submitable">
                                        <td>
                                            <label for="d_task<?php echo $task->getId(); ?>"><?php echo $task->getTitle(); ?></label>
                                            <input type="submit" class="hide" name="edit" id="d_task<?php echo $task->getId(); ?>" value="<?php echo $task->getId(); ?>"/>
                                        </td>
                                        <td><label for="d_task<?php echo $task->getId(); ?>"><?php echo date("Y/m/d", strtotime($task->getDateCreated())); ?></label></td>
                                        <td><label for="d_task<?php echo $task->getId(); ?>"><?php echo date("Y/m/d", strtotime($task->getDateModified())); ?></label></td>
                                        <td><label for="d_task<?php echo $task->getId(); ?>"><?php echo $task->getDesc(); ?></label></td>
                                    </tr>
                                    <?php
                                }
                            }

                            if ($devCount == 0)
                            {
                                ?>
                                <tr>
                                    <td colspan="4">There are currently no tasks in development.</td>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                        <input type="hidden" name="selectedTab" value="indev"/>
                    </form>
                </div>
            </div>
        </div>
        <div class="tab">
            <input type="radio" id="intest" name="tabGrp" value="intest" <?php echo ($selectedTab=="intest")?"checked":""; ?>/>
            <label for="intest">Testing</label>
            <div class="tabContent">
                <div class="tabContainer">
                    <form action="./manageTasks.php" method="post" class="ignoreFormatting">
                        <table class="expandLast hover">
                            <tr>
                                <th>Title</th>
                                <th>Created</th>
                                <th>Modified</th>
                                <th>Description</th>
                            </tr>
                            <?php
                            $testCount = 0;
                            foreach ($tasks as $task)
                            {
                                if ($task->getStatus() == 3)
                                {
                                    $testCount++;
                                    ?>
                                    <tr class="submitable">
                                        <td>
                                            <label for="tst_task<?php echo $task->getId(); ?>"><?php echo $task->getTitle(); ?></label>
                                            <input type="submit" class="hide" name="edit" id="tst_task<?php echo $task->getId(); ?>" value="<?php echo $task->getId(); ?>"/>
                                        </td>
                                        <td><label for="tst_task<?php echo $task->getId(); ?>"><?php echo date("Y/m/d", strtotime($task->getDateCreated())); ?></label></td>
                                        <td><label for="tst_task<?php echo $task->getId(); ?>"><?php echo date("Y/m/d", strtotime($task->getDateModified())); ?></label></td>
                                        <td><label for="tst_task<?php echo $task->getId(); ?>"><?php echo $task->getDesc(); ?></label></td>
                                    </tr>
                                    <?php
                                }
                            }
                            if ($testCount == 0)
                            {
                                ?>
                                <tr>
                                    <td colspan="4">There are currently no tasks to test.</td>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                        <input type="hidden" name="selectedTab" value="intest"/>
                    </form>
                </div>
            </div>
        </div>
        <div class="tab">
            <input type="radio" id="complete" name="tabGrp" value="complete" <?php echo ($selectedTab=="complete")?"checked":""; ?>/>
            <label for="complete">Complete</label>
            <div class="tabContent">
                <div class="tabContainer">
                    <form action="./manageTasks.php" method="post" class="ignoreFormatting">
                        <table class="expandLast hover">
                            <tr>
                                <th>Title</th>
                                <th>Created</th>
                                <th>Modified</th>
                                <th>Description</th>
                            </tr>
                            <?php
                            $completeCount = 0;
                            foreach ($tasks as $task)
                            {
                                if ($task->getStatus() == 4)
                                {
                                    $completeCount++;
                                    ?>
                                    <tr class="submitable">
                                        <td>
                                            <label for="c_task<?php echo $task->getId(); ?>"><?php echo $task->getTitle(); ?></label>
                                            <input type="submit" class="hide" name="edit" id="c_task<?php echo $task->getId(); ?>" value="<?php echo $task->getId(); ?>"/>
                                        </td>
                                        <td><label for="c_task<?php echo $task->getId(); ?>"><?php echo date("Y/m/d", strtotime($task->getDateCreated())); ?></label></td>
                                        <td><label for="c_task<?php echo $task->getId(); ?>"><?php echo date("Y/m/d", strtotime($task->getDateModified())); ?></label></td>
                                        <td><label for="c_task<?php echo $task->getId(); ?>"><?php echo $task->getDesc(); ?></label></td>
                                    </tr>
                                    <?php
                                }
                            }

                            if ($completeCount == 0)
                            {
                                ?>
                                <tr>
                                    <td colspan="4">There are currently no completed tasks.</td>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                        <input type="hidden" name="selectedTab" value="complete"/>
                    </form>
                </div>
            </div>
        </div>
        <div class="tab">
            <input type="radio" id="new" name="tabGrp" value="new" <?php echo ($selectedTab=="new")?"checked":""; ?>/>
            <label for="new">New</label>
            <div class="tabContent">
                <div class="tabContainer">
                    <form method="post" action="./manageTasks.php">
                        <p>
                            <label for="title">Title:</label>
                            <input type="text" name="title" id="title" class="<?php echo (empty($titleMsg))?"":"invalid error"; ?>" value="<?php echo $title; ?>"/>
                            <span class="errorMsg"><?php echo $titleMsg; ?></span>
                        </p>
                        <p>
                            <label for="desc">Description:</label>
                            <textarea name="desc" id="desc" class="<?php echo (empty($descMsg))?"":"invalid error"; ?>"><?php echo $desc; ?></textarea>
                            <span class="errorMsg"><?php echo $descMsg; ?></span>
                        </p>
                        <p>
                            <label>&nbsp;</label>
                            <input type="submit" name="newTask" id="newTask" value="Add Task"/>
                        </p>
                        <input type="hidden" name="selectedTab" value="new"/>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
<?php
        if (!empty($notificationMsg))
        {
?>
    <div class="notification-container">
        <input type="checkbox" id="close"/>
        <div class="notification">
            <div class="message"><?php echo $notificationMsg; ?></div>
            <label class="exit" for="close">Close</label>
        </div>
    </div>
<?php
       }
?>
</body>
</html>
<?php
    }
?>